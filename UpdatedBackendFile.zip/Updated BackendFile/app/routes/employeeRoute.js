const express = require("express");
const router = express.Router();
const middleware=require("../middlewares/validation")
const employeeContoller = require("../controllers/employeeContoller");

router.post("/saveEmpDetails",middleware.checkArrayValidation ,employeeContoller.employeeToDB) //save  employee data

router.get("/getEmpdetails",employeeContoller.DbToEmployee)   //Save employee data

module.exports = router;