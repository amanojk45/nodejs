const SUCCESS = 200;
const CREATED = 201;
const CONFLICT = 409;

const success = (res, data) => {
    res.status(SUCCESS).send({
        status: 'SUCCESS',
        data
    });
}

const created = (res, data) => {
    res.status(CREATED).send({
        status: 'SUCCESS',
        data
    });
}

const conflict = (res, code, message, description) => {
    res.status(CONFLICT).send({
        status: 'FAILURE',
        data: {
            error: {
                code,
                message,
                description,
            }
        }
    })
}

module.exports = {
    success,
    created,
    conflict,
}