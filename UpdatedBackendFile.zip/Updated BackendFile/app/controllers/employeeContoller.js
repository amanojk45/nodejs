const httpStatus = require("http-status");
const employeeService = require("../services/employeeService");
const constants = require("../utlis/constants");

const employeeToDB = async (req, res) => {
  try {
    const employeeData = req.body.sendData;
    const ListData = await employeeService.createEmpData(employeeData);
    if (ListData.dataInserted == true) {
      return res
        .status(201)
        .send({ code: httpStatus.OK, message: constants.INSERTED_SUCCESSULLY });
    } else {
      return res
        .status(206)
        .send({
          code: httpStatus.OK,
          message: constants.NOT_INSERTED,
          differnce: ListData.Difference,
        });
    }
  } catch (error) {
    console.log(error);
  }
};

const DbToEmployee = async (req, res) => {
  try {
    const Data = await employeeService.getEmployeeData();
    if (!Data) {
      return res
        .status(404)
        .send({ code: httpStatus.OK, message: constants.CANNOT_FETCH });
    }
    return res
      .status(200)
      .send({
        code: httpStatus.OK,
        message: constants.SUCCESSULLY_FETECHED,
        data: Data,
      });
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  employeeToDB,
  DbToEmployee,
};
