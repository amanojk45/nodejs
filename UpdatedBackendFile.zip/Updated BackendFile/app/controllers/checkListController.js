//package import
const httpStatus = require("http-status");
const checkListService = require("../services/checkListService");
const constants = require("../utlis/constants");

const checkListToDb = async (req, res) => {
  try {
    const { ColumnHeader, sendData, obj } = req.body;
    const checklistTable = await checkListService.GenerateDynamicCheckList(
      ColumnHeader,
      sendData,
      obj
    );
    if (checklistTable === true) {
      return res
        .status(201)
        .send({ code: httpStatus.OK, message: constants.INSERTED_SUCCESSULLY });
    } else {
      return res
        .status(206)
        .send({ code: httpStatus.OK, message: constants.NOT_INSERTED });
    }
  } catch (error) {
    console.log(error);
  }
};

//get CheckList On click On checklist dropdown
const getCheckLists = async (req, res) => {
  try {
    const data = await checkListService.getCheckLists();
    if (data) {
      return res.status(200).send({
        code: httpStatus.OK,
        message: constants.SUCCESSULLY_FETECHED,
        data: data,
      });
    } else {
      return res
        .status(400)
        .send({ code: httpStatus.OK, message: constants.CANNOT_FETCH });
    }
  } catch (error) {
    console.log(error);
  }
};

//get CheckList On click On checklist dropdown
const getCheckListByName = async (req, res) => {
  try {
    const checkListName = req.body;
    const data = await checkListService.getCheckListByName(checkListName);
    if (data) {
      return res.status(200).send({
        code: httpStatus.OK,
        message: constants.SUCCESSULLY_FETECHED,
        data: data,
      });
    } else {
      return res
        .status(400)
        .send({ code: httpStatus.OK, message: constants.CANNOT_FETCH });
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  checkListToDb,
  getCheckLists,
  getCheckListByName,
};
