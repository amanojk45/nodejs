'use strict';
const  Sequelize = require('sequelize');
const sequelize = require('../../db.config');
require("dotenv").config();

let db = {};

db.sequelize = sequelize;
db.Sequelize = Sequelize;
db.users = require("./user")(sequelize, Sequelize);
db.employeeData = require("./employee")(sequelize, Sequelize);
db.projectData = require("./project")(sequelize, Sequelize);
db.masterAudit = require("./masterAudit")(sequelize, Sequelize);
db.masterCheckList = require("./master_checklist")(sequelize, Sequelize);
db.auditTeam = require("./audit_team")(sequelize, Sequelize);
db.auditStatus = require('./audit_status')(sequelize, Sequelize);

module.exports = db;