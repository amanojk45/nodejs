import React from 'react';
import { Button } from 'antd';
import 'antd/dist/antd.css';

const Logout = function () {

  const handleClear = () => {
    localStorage.removeItem('accessToken');
  };

  return (
    <div>
      <h1>Logout Page</h1>
      <Button type='primary' onClick={handleClear} style={{ marginBottom: '10px' }}>clear Token</Button>
    </div>
  );
};
export default Logout;

