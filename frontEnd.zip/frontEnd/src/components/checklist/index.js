import React, { useState } from 'react';
import 'antd/dist/antd.css';
import * as XLSX from 'xlsx';
import {
  Table, Button, Space, Popconfirm, Upload, PageHeader, Input, message, Typography,
} from 'antd';
import { UploadOutlined, UserOutlined, DatabaseOutlined, SaveOutlined, DeleteOutlined } from '@ant-design/icons';

const Checklist = function () {
  const [showTable, setShowTable] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [sendData, setSendData] = useState([]);
  const [checklistname, setChecklistName] = useState('');
  const [checklisttype, setChecklistType] = useState('');

  const handleUpload = (e) => {
    setShowTable(true);
    const reader = new FileReader();
    // evt = on_file_select event
    reader.onload = (evt) => {
      /* Parse data */
      const data = evt.target.result;
      const wb = XLSX.read(data, { type: 'binary' });
      const sheet = wb.SheetNames[0];
      const excel = wb.Sheets[sheet];
      const excelEntry = XLSX.utils.sheet_to_json(excel, { header: 1, blankrows: false });

      const excelData = [];
      excelEntry.forEach((row) => {
        if (row[0] === undefined) {
          row.shift();
          excelData.push(row);
        } else {
          excelData.push(row);
        }
      });

      const headingName = [];
      excelData.forEach((columnName) => {
        if (columnName.length === 1) {
          const index = excelData.indexOf(columnName);
          headingName.push(index);
        }
      });

      if (headingName.length > 1) {
        let TableRowData = [];
        /* eslint-disable no-plusplus */
        for (let i = 0; i < headingName.length; i++) {
          const array = excelData.slice(headingName[i], headingName[i + 1]);

          const keys = array[1];

          const values = array.slice(2);

          let objects = values.map((arrayData) => {
            const object = {};
            /* eslint-disable no-return-assign */
            keys.forEach((key, j) => object[key.trim()] = arrayData[j]);
            return object;
          });

          if (array[0].length === 1) {
            objects = objects.map((obj) => {
              const keyValues = Object.entries(obj);
              keyValues.splice(1, 0, ['Type', array[0].toString()]);
              /* eslint-disable no-param-reassign */
              obj = Object.fromEntries(keyValues);
              return obj;
            });
          }
          TableRowData = [...TableRowData, ...objects];
        }

        const result = [];
        TableRowData.forEach((cloumnData) => {
          const entries = Object.entries(cloumnData);
          /* eslint-disable no-unused-vars */
          const filtered = entries.filter(([key, val]) => val !== undefined);
          const output = Object.fromEntries(filtered);
          result.push(output);
        });

        setTableData(result);

        setSendData(TableRowData);
      } else {
        const keys = excelData[1];
        const values = excelData.slice(2);

        let objects = values.map((array) => {
          const object = {};
          /* eslint-disable no-return-assign */
          keys.forEach((key, i) => object[key] = array[i]);
          return object;
        });

        if (excelData[0].length === 1) {
          objects = objects.map((obj) => {
            const keyValues = Object.entries(obj);
            keyValues.splice(1, 0, ['Type', excelData[0].toString()]);
            obj = Object.fromEntries(keyValues);
            return obj;
          });
        }

        const result = [];
        objects.forEach((objectData) => {
          const entries = Object.entries(objectData);
          const filtered = entries.filter(([key, val]) => val !== undefined);
          const output = Object.fromEntries(filtered);
          result.push(output);
        });

        setTableData(result);
        setSendData(objects);
      }
    };
    reader.readAsBinaryString(e.file);
  };

  const TableColumns = [];
  tableData.forEach((data) => {
    /* eslint-disable no-restricted-syntax */
    for (const k in data) {
      if (TableColumns.indexOf(k) === -1) {
        TableColumns.push(k);
      }
    }
  });

  const ColumnHeader = [];
  sendData.forEach((header) => {
    /* eslint-disable no-restricted-syntax */
    for (const l in header) {
      if (ColumnHeader.indexOf(l) === -1) {
        ColumnHeader.push(l);
      }
    }
  });

  const TableColumnsData = [];
  TableColumns.forEach((data, i) => {
    TableColumnsData.push({
      title: data,
      dataIndex: data,
      key: i,
      width: 150,
    });
  });

  const handleNameChange = (e) => {
    setChecklistName(e.target.value);
  };

  const handleTypeChange = (e) => {
    setChecklistType(e.target.value);
  };

  const handleSaveClick = (importedData, ColumnHeaderName) => {
    const obj = {
      name: checklistname,
      type: checklisttype,
    };
    fetch('http://localhost:4000/checklist/saveChecklist', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ ColumnHeader, sendData, obj }),
    }).then((Data) => {
      if (Data.status === 200) {
        message.success('File Uploaded');
      } else {
        message.error('File Not Uploaded');
      }
    });
  };

  return (
    <div>
      <div style={{ marginBottom: '16px' }}>
        <PageHeader style={{ fontSize: '32px' }}>Checklist</PageHeader>
      </div>
      <div style={{
        display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px',
      }}
      >
        <div style={{
          display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        }}
        >
          <div style={{
            display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginRight: '20px',
          }}
          >
            <Typography style={{ marginRight: '5px' }}>Name: </Typography>
            <Input placeholder="Enter Checklist Name" prefix={<UserOutlined />} onChange={handleNameChange} />
          </div>
          <div style={{
            display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
          }}
          >
            <Typography style={{ marginRight: '5px' }}>Type:</Typography>
            <Input placeholder="Enter Checklist Type" prefix={<DatabaseOutlined />} onChange={handleTypeChange} />
          </div>
        </div>
        <div>
          <Space>
            <Upload
              accept=".xlsx, .xlsm"
              showUploadList={false}
              beforeUpload={(file) => false}
              onChange={handleUpload}
            >
              <Button type="primary">
                <UploadOutlined />
                Upload Checklist
              </Button>
            </Upload>
            <Button type="primary" onClick={() => handleSaveClick(sendData, ColumnHeader)}><SaveOutlined />Save</Button>
            <Popconfirm title="Are you sure delete this Record?" okText="Yes" cancelText="No">
              <Button type="primary"><DeleteOutlined />Delete</Button>
            </Popconfirm>
          </Space>
        </div>
      </div>

      {showTable
        && (
          <Table
            columns={TableColumnsData}
            dataSource={tableData}
            rowKey={Math.random().toString()}
            scroll={{ x: 200, y: 400 }}
            pagination={false}
            bordered
          />
        )}
    </div>
  );
};

export default Checklist;
