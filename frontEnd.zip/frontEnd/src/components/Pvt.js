import React from 'react';
import { Route, Redirect } from 'react-router-dom';

/* eslint-disable react/prop-types */
const Pvt = function ({ component: Component, ...rest }) {
  const accessToken = localStorage.getItem('accessToken');
  return (
    <div>
      <Route
        /* eslint-disable react/jsx-props-no-spreading */
        {...rest}
        render={(props) => (
          /* eslint-disable react/jsx-props-no-spreading */
          accessToken !== null ? <Component {...props} /> : <Redirect to="/" />
        )}
      />
    </div>
  );
};

export default Pvt;
