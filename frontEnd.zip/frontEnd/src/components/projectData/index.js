import React, { useState } from 'react';
import 'antd/dist/antd.css';
import * as XLSX from 'xlsx';
import {
  Table, Button, Space, Popconfirm, Upload, PageHeader, Input, message,
} from 'antd';
import { UploadOutlined, SaveOutlined, DeleteOutlined } from '@ant-design/icons';

const ProjectData = function () {
  const [showTable, setShowTable] = useState(false);
  const [tableData, seTableData] = useState([]);
  const [sendData, setSendData] = useState([]);
  const [filterTable, setFilterTable] = useState(null);

  const handleUpload = (e) => {
    setShowTable(true);
    const reader = new FileReader();

    reader.onload = (evt) => {
      const data = evt.target.result;
      const wb = XLSX.read(data, { type: 'binary' });
      const sheet = wb.SheetNames[0];
      const excel = wb.Sheets[sheet];
      const excelData = XLSX.utils.sheet_to_json(excel).map((row) => Object.keys(row).reduce((obj, key) => {
        /* eslint-disable no-param-reassign */
        obj[key.trim()] = row[key];
        return obj;
      }, {}));
      seTableData(excelData);
      setSendData(excelData);
    };
    reader.readAsBinaryString(e.file);
  };

  const TableColumns = [];
  tableData.forEach((data) => {
    /* eslint-disable no-restricted-syntax */
    for (const k in data) {
      if (TableColumns.indexOf(k) === -1) {
        TableColumns.push(k);
      }
    }
  });

  const TableColumnsData = [];
  TableColumns.forEach((data, i) => {
    TableColumnsData.push({
      title: data,
      dataIndex: data,
      key: i,
      width: 150,
    });
  });

  const handleSaveClick = (importedData) => {
    fetch('http://localhost:4000/projectData/saveProjectData', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(importedData),
    }).then((Data) => {
      if (Data.status === 201) {
        message.success('File Uploaded');
      } else {
        message.error('File Not Uploaded');
      }
    });
  };

  const handleSearch = (value) => {
    const filteredData = tableData.filter((key) => Object.keys(key).some((data) => String(key[data])
      .toLowerCase()
      .includes(value.toLowerCase())));
    setFilterTable(filteredData);
  };

  return (
    <div>
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px',
      }}
      >
        <div>
          <PageHeader style={{ fontSize: '32px' }}>Project Data</PageHeader>
        </div>
        <div>
          <Space>
            <Input.Search placeholder="Search by.." onSearch={handleSearch} enterButton />
            <Upload
              accept=".xlsx, .xlsm"
              showUploadList={false}
              beforeUpload={(file) => false}
              onChange={handleUpload}
            >
              <Button type="primary">
                <UploadOutlined />
                Upload Data
              </Button>
            </Upload>
            <Button type="primary" disabled={!showTable} onClick={() => handleSaveClick(sendData)}><SaveOutlined />Save</Button>
            <Popconfirm title="Are you sure delete this Record?" okText="Yes" cancelText="No" >
              <Button type="primary" disabled={!showTable}><DeleteOutlined />Delete</Button>
            </Popconfirm>
          </Space>
        </div>
      </div>
      {showTable && <Table columns={TableColumnsData} dataSource={filterTable === null ? tableData : filterTable} scroll={{ x: 200, y: 400 }} bordered pagination={false} style={{ marginBottom: '30px' }} />}
    </div>
  );
};

export default ProjectData;
