import React from 'react';
import '../../index.css';

const Report = function () {
    return (
        <div className="pagecenter">
            <h1>Report Page</h1>
        </div>
    );
};

export default Report;