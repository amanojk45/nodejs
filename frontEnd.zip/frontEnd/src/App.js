import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { Spin } from 'antd';

import Sidebar from './Sidebar';
import Login from './components/login';
import SignUp from './components/signUp';
import Pvt from './components/Pvt';

import './App.css';

const App = function () {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // setTimeout(() => {
    setLoading(false);
    // }, 2000);
  }, [loading]);

  return (
    loading ? (
      <div className='pagecenter'>
        <Spin size="large" />
      </div>
    ) : (
        <Router>
          <Switch>
            <Route path="/signup" exact component={SignUp} />
            <Route path="/" exact component={Login} />
            <Pvt path="/audit-tool" component={Sidebar} />
          </Switch>
        </Router>
      )
  );
};

export default App;
