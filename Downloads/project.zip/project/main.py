#from flask import Blueprint, render_template
#import SentimentAnalysis
from . import db
from flask import Flask, request, render_template, Blueprint
from flask_login import login_required, current_user
#import pandas as pd
#import numpy as np
main = Blueprint('main', __name__)
#import json
#import plotly
import os


@main.route('/', methods=['POST', 'GET'])
def index():   
 return render_template('index.html')

@main.route('/send_data', methods = ['POST'])

def get_data_from_html():      
        Current = request.form['Current']
        SOC = request.form['SOC']
        Time = request.form['Time']
        Ton = request.form['Ton']
        Toff = request.form['Toff']
        Amb_Temp = request.form['Amb_Temp']

        if Current=="":
          print("Current is not provided")
        else:
         print (" Current is  provided")
         with open('/home/bhagyashree.hajeri/flask_auth_app/project/static/CC.txt','w+') as f:
                f.write(str(Current)+' ')
                f.close()
        
        if SOC=="":
          print("SOC is not provided")
        else:
          with open('/home/bhagyashree.hajeri/flask_auth_app/project/static/CC.txt', 'a') as f:
                f.write(str(SOC)+' ')
                f.close()

        if Time =="":
          print("Time is not provided")
        else:
          with open('/home/bhagyashree.hajeri/flask_auth_app/project/static/CC.txt', 'a') as f:
                f.write(str(Time)+' ')
                f.close()
 
        if Ton =="":
          print("Ton is not provided")
        else:
          with open('/home/bhagyashree.hajeri/flask_auth_app/project/static/CC.txt', 'a') as f:
                f.write(str(Ton)+' ')
                f.close()
        
        if Toff =="":
          print("Toff is not provided")
        else:
          with open('/home/bhagyashree.hajeri/flask_auth_app/project/static/CC.txt', 'a') as f:
                f.write(str(Toff)+' ')
                f.close()

        if Amb_Temp =="":
          print("Temp is not provided")
        else:
          with open('/home/bhagyashree.hajeri/flask_auth_app/project/static/CC.txt', 'a') as f:
                f.write(str(Amb_Temp)+' ')
                f.close()
        
        return render_template('index.html')

@main.route('/profile')
@login_required
def profile():
    
    os.system("/home/bhagyashree.hajeri/flask_auth_app/project/static/start.sh")
    return render_template('profile.html', name=current_user.name)






