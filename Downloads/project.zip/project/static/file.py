from matplotlib import pyplot as plt
from matplotlib import style
import numpy as np

style.use('ggplot')

x,y = np.loadtxt('/home/bhagyashree.hajeri/flask_auth_app/project/static/CC_data.csv',
                unpack = True,
                delimiter =',' )
xt,yt = np.loadtxt('/home/bhagyashree.hajeri/flask_auth_app/project/static/Temp_CC_data.csv',
                unpack = True,
                delimiter =',' )
x2,y2 = np.loadtxt('/home/bhagyashree.hajeri/flask_auth_app/project/static/PC_data.csv',
                unpack = True,
                delimiter =',' )
x2t,y2t = np.loadtxt('/home/bhagyashree.hajeri/flask_auth_app/project/static/Temp_PC_data.csv',
                unpack = True,
                delimiter =',' )
x3,y3 = np.loadtxt('/home/bhagyashree.hajeri/flask_auth_app/project/static/CCCV_data1.csv',
                unpack = True,
                delimiter =',' )
x4,y4 = np.loadtxt('/home/bhagyashree.hajeri/flask_auth_app/project/static/CCCV_data2.csv',
                unpack = True,
                delimiter =',' )
x3t,y3t = np.loadtxt('/home/bhagyashree.hajeri/flask_auth_app/project/static/Temp_CCCV_data.csv',
                unpack = True,
                delimiter =',' )
plt.figure(1)
plt.plot(x,y)

plt.title('Continuous Charging ')
plt.ylabel('SOC')
plt.xlabel('Time')
plt.text(x[-1],y[-1],("{:.2f}".format(y[-1])))
plt.text(x[-1],y[-1]-10,(x[-1]))
plt.savefig('/home/bhagyashree.hajeri/flask_auth_app/project/static/CC.png')
#plt.show()
plt.figure(2)
plt.plot(x2,y2)

plt.title('Pulse charging')
plt.ylabel('SOC')
plt.xlabel('Time')
plt.text(x2[-1],y2[-1],("{:.2f}".format(y2[-1])))
plt.text(x2[-1],y2[-1]-10,(x2[-1]))
plt.savefig('/home/bhagyashree.hajeri/flask_auth_app/project/static/PC.png')
#plt.show()
plt.figure(3)
plt.plot(x3,y3)
plt.plot(x4,y4)

plt.title('CC-CV Charging')
plt.ylabel('SOC')
plt.xlabel('Time')
plt.text(x4[-1],y4[-1],("{:.2f}".format(y4[-1])))
plt.text(x4[-1],y4[-1]-10,(x4[-1]))
plt.savefig('/home/bhagyashree.hajeri/flask_auth_app/project/static/CCCV.png')

plt.figure(4)
plt.plot(xt,yt)

plt.title('Battery Temperature');
plt.ylabel('Temperature')
plt.xlabel('Time')
plt.text(xt[-1],yt[-1],("{:.2f}".format(yt[-1])))
#plt.text(x4[-1],y4[-1]-10,(x4[-1]))
plt.savefig('/home/bhagyashree.hajeri/flask_auth_app/project/static/Temp_CC.png')

plt.figure(5)
plt.plot(x2t,y2t)

plt.title('Battery Temperature');
plt.ylabel('Temperature')
plt.xlabel('Time')
plt.text(x2t[-1],y2t[-1],("{:.2f}".format(y2t[-1])))
#plt.text(x4[-1],y4[-1]-10,(x4[-1]))
plt.savefig('/home/bhagyashree.hajeri/flask_auth_app/project/static/Temp_PC.png')

plt.figure(6)
plt.plot(x3t,y3t)

plt.title('Battery Temperature');
plt.ylabel('Temperature')
plt.xlabel('Time')
plt.text(x3t[-1],y3t[-1],("{:.2f}".format(y3t[-1])))
#plt.text(x4[-1],y4[-1]-10,(x4[-1]))
plt.savefig('/home/bhagyashree.hajeri/flask_auth_app/project/static/Temp_CCCV.png')

