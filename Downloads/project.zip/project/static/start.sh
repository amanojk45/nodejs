
#python3 main.py
 
#cd Scilab
#cd bin
#scilab -f /home/bhagyashree.hajeri/flask_auth_app/project/static/CC_Web_GUI.sce
#scilab -f /home/bhagyashree.hajeri/flask_auth_app/project/static/PC_Web_GUI.sce
#scilab -f /home/bhagyashree.hajeri/flask_auth_app/project/static/CCCV_Web_GUI.sce
scilab -f /home/bhagyashree.hajeri/flask_auth_app/project/static/Web_GUI_Temp.sce
python3 /home/bhagyashree.hajeri/flask_auth_app/project/static/file.py

