

const AuditNotClose = {
    subject: 'Audit Not Closed',
    text:'just checking',
    html: 'Your Audit is Still in pending,Please Close As Early as Possible.This message is Sent As Only two days remaining for the Final Audit Date <br>',
}

const sendDraftData={
    subject:"just checking Dont Mind",
    text:'just checking',
    html: "clicked send Draft <br>",
}

module.exports={
    AuditNotClose,
    sendDraftData
}