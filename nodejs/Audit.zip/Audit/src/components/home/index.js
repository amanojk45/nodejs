import React from 'react';
import '../../index.css';

const Home = () => (
  <div className="pagecenter">
    <h1>Home Page</h1>
  </div>
);

export default Home;
